﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureGame2026
{
    public class Item
    {
        public string ItemName = "Item";
        public string ItemDescription = "The item is iteming.";
        public double Value = 3.24; //float (3.5f), double, decimal (3.5m)
        public int Price = 5;

        
        public Item(string itemName, string itemDescription, double value)
        {
            ItemName = itemName;
            ItemDescription = itemDescription;
            Value = value;
        }

        public Item()
        {
        }

    }
}
