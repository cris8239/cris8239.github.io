﻿
//using directives
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace AdventureGame2026
{
    public class World
    {
        public string WorldName;
        public string Description;
        public List<Location> Locations = new List<Location>();
        
        public Person NPCMerchant;
        private string title = @"
                                                                                                  
                                _ _         
  /\/\   __ _  __ _ _ __   ___ | (_) __ _ 
 /    \ / _` |/ _` | '_ \ / _ \| | |/ _` |
/ /\/\ \ (_| | (_| | | | | (_) | | | (_| |
\/    \/\__,_|\__, |_| |_|\___/|_|_|\__,_|
              |___/                                                                                  
                EST. 1929
";

        //https://programmingisfun.com/command-line-ascii-design/
        //string title = @"";
        //Console.WriteLine(title);
        

public string VisitWorld()
        {
            string output = $"Welcome to {WorldName}! \n{Description}\nThese are the locations you could visit:\n";
            foreach(Location location in Locations)
            {
                output += $"   * {location.LocationName}.\n";
            }
            return output;
        }
    }
}