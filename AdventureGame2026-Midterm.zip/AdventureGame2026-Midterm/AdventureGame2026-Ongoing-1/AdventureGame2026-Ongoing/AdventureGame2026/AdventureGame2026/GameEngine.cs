﻿//BOOKMARK: CONTINUE THE CLASS RECAP FROM 2/12/2026, TIME LEFT OFF AT 59:06 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static AdventureGame2026.Utility;

namespace AdventureGame2026
{
    class GameEngine
    {

        //multiple worlds
        public List<World> Worlds { get; set; } = new List<World>();
        public Person Player;
        World CurrentWorld;

        public void SetUpWorld()
        {
            //TODO: set up multiple worlds and select current world
            CurrentWorld = Worlds[0];
            CurrentWorld.WorldName = @"
                                                                                                  
                                _ _         
  /\/\   __ _  __ _ _ __   ___ | (_) __ _ 
 /    \ / _` |/ _` | '_ \ / _ \| | |/ _` |
/ /\/\ \ (_| | (_| | | | | (_) | | | (_| |
\/    \/\__,_|\__, |_| |_|\___/|_|_|\__,_|
              |___/                                                                                  
                EST. 1929
";
            CurrentWorld.Description = "The county where pizza does not exist, and nobody knows of it's existence. Perhaps it's time you changed that.";
            CurrentWorld.Locations.Add(new Location() { LocationName = "Antipasto Plaza", Description = "Where most residents do their shopping and dining." });
            CurrentWorld.Locations.Add(new Location() { LocationName = "Pizza-less Park", Description = "A park not too far from the pier. Take a nice long walk." });
            CurrentWorld.Locations.Add(new Location() { LocationName = "Fettuccine Forst", Description = "The forest preserve residing on the east side of the suburbs." });
            CurrentWorld.Locations.Add(new Location() { LocationName = "Bruscheta Boardwalk", Description = "The main pier of the town, also home to small luxury lakeside cruises." });
            Title = CurrentWorld.WorldName;

            Player = new Person("Cris", "Adventurer");
            CurrentWorld.NPCMerchant = new Person("Kyle", "Merchant");

            //TODO: add worlds to list and select current world
            Run();

        }
        public void Run()
        {
            Print($"Welcome to {CurrentWorld.WorldName}");
            Print($"{CurrentWorld.Description}");
            Print($"");
            Print($"Your name has been preselected as: {Player.Name}");
            Print($"Would you like to change your name?");
            Print($"");
            string input = GetUserInput("Enter 'y' for yes. Any other key will begin the game.");

            if (input.ToLower() == "y")
            {
                Clear();
                Print($"");
                Print("Enter your new name:");
                string newName = ReadLine();
                if (!string.IsNullOrWhiteSpace(newName))
                {
                    Player.Name = newName;
                }
                Print($"");
                Print($"Your name has been changed to {Player.Name}.");
            }
            Print($"");
            // Print("note: Displaying using DisplayInventory method:"); 
            Player.DisplayInventory();

            Print($"");
            Print($".....game starts here....");
            ReadKey(); //temporary for window to stay open
            Clear();

            Print("Current location: Home");
            Print("3/26/2026");

            Print($"");
            Print($"");
            Print($"* You wake up in your bedroom one a Saturday morning seeing that you left your TV on for the entire night.");
            ReadKey();
            Print($"* So you get out of bed to turn it off.");
            ReadKey();
            Print($"* You smell the lightly salted eggs and bacon downstairs and decide to walk downstairs and see if breakfast is ready.");
            ReadKey();

            Print($"");
            Print($"* Your plate is already on the table.");
            ReadKey();

            Print($"");

            Person person = new Person();

            string result1 = person.AskChoice(
                ">* You sit at the table and are now staring at the plate...",
                "Eat some eggs",
                "Eat some bacon",
                "Eat some toast"
            );

            Console.WriteLine($"You chose: {result1}\n");

            string result2 = person.AskChoice(
                ">* What else will you eat?",
                "Eggs",
                "Bacon",
                "Toast"
            );

            Console.WriteLine($"You chose: {result2}");
            ReadKey();
            Clear();

            Print($"");
            Print($"I feel like something is missing here.");
            Print($"");
            ReadKey();

            Person person1 = new Person();

            string result = person.AskChoice(
                "> Maybe if I had some spread or a condiment...",

                "Grab ketchup", "Good with eggs, but if only there were some hash browns too.",
                "Grab Cholula hot sauce", "It tastes great with the eggs.",
                "Grab avocado", "This could make for a good avacado toast with the bacon that's left."
            );

            Clear();
            Console.WriteLine(result);
            ReadKey();

            Print($"...");
            ReadKey();
            Print($"...");
            ReadKey();
            Clear();
            Print($"Why do I feel like I've had this several times before?");
            Print($"This is getting old.");
            ReadKey();

            Clear();
            Print($"It's the same thing again and again.");
            Print($"The most generic plate of morning food ever. The stuff you see in the old romcoms with the average nuclear family.");
            ReadKey();
            Print($"");
            Print($"I mean I'm grateful for being able to even have food on the table to begin with.");
            Print($"But seriously, why is there never a switchup?");
            ReadKey();

            Print($"");
            Print($"Guess I'll never really know.");
            ReadKey();

            Print($"");
            Print($"* You finish your plate of food and step out of the house later on...");
            ReadKey();
            Clear();

            Print($"Where to go now...");
            Print($"");
            Print($"! You have obtained a map.");
            // End

            ReadKey();
            Clear();





        }

        private void menu()
        {
            string option = ReadLine();

            if (Utility.ConvertStringToInteger(option) == 1)
            {

            }
        }
    }
}
