﻿using static System.Console;

namespace AdventureGame2026
{
    public class Person 
    {
        public string Name;
        public string Role;
        public List<Item> Inventory = new List<Item>();

        //new choice (without different dialogue)
        public string AskChoice(string prompt, string option1, string option2, string option3)
        {
            string input;

            do
            {
                Console.WriteLine(prompt);
                Console.WriteLine($"1. {option1}");
                Console.WriteLine($"2. {option2}");
                Console.WriteLine($"3. {option3}");
                Console.Write("Enter 1, 2, or 3: ");

                input = Console.ReadLine();

                if (input != "1" && input != "2" && input != "3")
                {
                    Clear();
                    Console.WriteLine("Invalid choice. Try again.\n");
                }

            } while (input != "1" && input != "2" && input != "3");

            return input switch
            {
                "1" => option1,
                "2" => option2,
                "3" => option3
            };
        }

        //new choice (with different option-based) dialogue
        public string AskChoice(
        string prompt,
        string option1, string response1,
        string option2, string response2,
        string option3, string response3)
        {
            string input;

            do
            {
                Console.WriteLine(prompt);
                Console.WriteLine($"1. {option1}");
                Console.WriteLine($"2. {option2}");
                Console.WriteLine($"3. {option3}");
                Console.Write("Enter 1, 2, or 3: ");

                input = Console.ReadLine();

                if (input != "1" && input != "2" && input != "3")
                {
                    Clear();
                    Console.WriteLine("Invalid choice. Try again.\n");
                }

            } while (input != "1" && input != "2" && input != "3");

            return input switch
            {
                "1" => response1,
                "2" => response2,
                "3" => response3
            };

        }

        // Constructor
        public Person(string name, string role)
        {
            Name = name;
            Role = role;
            setUpInventory();
        }
        public Person()
        {
            setUpInventory();
        }


        //no separation of concern between presentation and logic
        public void DisplayInventory()
        {
            WriteLine($"{Name}'s Inventory:");
            foreach (Item temporaryItem in Inventory)
            {
                WriteLine($"- {temporaryItem.ItemName}: {temporaryItem.ItemDescription} (Price: {temporaryItem.Price})");
            }
          
        }

        //separate presentation of a specific item from the logic of setting up the inventory
        public string GetInventoryInformation()
        {
            string output = $"{Name}'s Inventory:\n";
            //string output = Name + "'s Inventory:\n";

            foreach (Item temporaryItem in Inventory)
            {
                output += $"~ {temporaryItem.ItemName}: {temporaryItem.ItemDescription} (Price: {temporaryItem.Price})\n";
            }

            return output;
        }


        private void setUpInventory()
        {
            // Placeholder for inventory setup logic
            //arrayname.Length; 
            //arrayname.Length-1;
            //listname.Count;
            //listname.Count-1;

            //two steps
            Item map = new Item(
                "Map of Suburbs",
                "A detailed map showing the outskirts and innards of the Magnolian suburbs.",
                0
                );
            Inventory.Add(map);

            //one step version 1
            //using a constructor with parameters
            Inventory.Add(
                new Item(
                    "Long wooden Stick",
                    "Awesome stick description",
                    2.189
                    ));

            //one step version 2
            //using object initializer syntax
            Inventory.Add(
                new Item()
                {
                    ItemName = "Sliced Pepperoni",
                    ItemDescription = "A fresh pack of sliced pepperoni from the super market. (Nobody in this town has ever used it to make pizza. Not even once.)",
                    Price = 1
                }
                );



        }
    }
}
