﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureGame2026
{
    public class Location
    {
        public string LocationName;
        public string Description;

        //TODO: add items and NPCs to location
    }
}
